
const receita = {
    nome: '',
    ingredientes: [{nome:'' , quantidade: 0}],
    modoPreparo: '',
}

